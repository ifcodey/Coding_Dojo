package com.codingdojo.qa3ati;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Qa3atiApplicationTests {

	@Test
	void contextLoads() {
	}

}
