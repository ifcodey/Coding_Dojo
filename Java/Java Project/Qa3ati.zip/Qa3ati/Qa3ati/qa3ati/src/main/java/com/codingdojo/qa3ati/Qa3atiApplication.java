package com.codingdojo.qa3ati;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Qa3atiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Qa3atiApplication.class, args);
	}

}
